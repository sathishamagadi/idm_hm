package com.Happiest.idm_db.service;

import com.Happiest.idm_db.entities.Enterprise;

import java.util.List;


public interface EnterpriseService {
	 public List<Enterprise> findAll();
	 
	 public Enterprise findByEnterpriseCode(String theEnterpriseCode);

}
