package com.Happiest.idm_db.dto;

import java.util.List;

import javax.persistence.EntityManager;

import com.Happiest.idm_db.entities.PasswordPolicy;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;




@Repository
public class PasswordPolicydtohibernateImpl implements PasswordPolicydto 
{
    private EntityManager entityManager;
    
    @Autowired
    public PasswordPolicydtohibernateImpl( EntityManager theEntityManager) {
   	 
   	 entityManager = theEntityManager;
   	 
    }
	
	
	
	@Override
	public List<PasswordPolicy> findAll() 
	{
	Session currentSession = entityManager.unwrap(Session.class);
	
	Query<PasswordPolicy> theQuery =  currentSession.createQuery("from PasswordPolicy",PasswordPolicy.class);
	
	   List<PasswordPolicy> allPasswordPolicy = theQuery.getResultList();
	
	return allPasswordPolicy ;
		
	}



}
