package com.Happiest.idm_db.service;

import java.util.List;

import com.Happiest.idm_db.dto.RoledtoHibernateImpl;
import com.Happiest.idm_db.entities.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class RoleServiceHibernateImpl implements RoleService {
	
	
	private RoledtoHibernateImpl roleDtoHibernateimpl;
	
	@Autowired
	public RoleServiceHibernateImpl(RoledtoHibernateImpl theRoleDtoHibernateimpl)
	{
		roleDtoHibernateimpl = 	theRoleDtoHibernateimpl;
	}
	

	@Override
	public List<Role> findAll()
	{
		return  roleDtoHibernateimpl.findAll();
	}


	@Override
	public void save(Role theRole) 
	{
		roleDtoHibernateimpl.save(theRole);
		
	}

}
