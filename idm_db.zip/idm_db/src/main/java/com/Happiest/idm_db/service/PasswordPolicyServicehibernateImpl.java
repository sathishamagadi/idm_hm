package com.Happiest.idm_db.service;

import java.util.List;

import javax.transaction.Transactional;

import com.Happiest.idm_db.dto.PasswordPolicydtohibernateImpl;
import com.Happiest.idm_db.entities.PasswordPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class PasswordPolicyServicehibernateImpl implements PasswordPolicyService
{

	private PasswordPolicydtohibernateImpl passwordPolicydtohibernateImpl;
	
	@Autowired
	public PasswordPolicyServicehibernateImpl(PasswordPolicydtohibernateImpl   thePasswordPolicydtohibernateImpl ) {
		passwordPolicydtohibernateImpl = thePasswordPolicydtohibernateImpl;
	}


	@Override
	@Transactional
	public List<PasswordPolicy> findAll()
	{
	    return	passwordPolicydtohibernateImpl.findAll();
	}


}
