package com.Happiest.idm_db.controller;

import java.util.List;

import com.Happiest.idm_db.entities.PasswordPolicy;
import com.Happiest.idm_db.service.PasswordPolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping("/api")
public class PasswordPolicyRestController
{
private PasswordPolicyService passwordPolicyService;
	
	@Autowired
	public PasswordPolicyRestController(PasswordPolicyService thePasswordPolicyService)
	{
		passwordPolicyService =  thePasswordPolicyService;
	}
    
	@GetMapping("/passwordpolicies")
	public List<PasswordPolicy> findAllRoles()
	{
		return passwordPolicyService.findAll();

    }

}
