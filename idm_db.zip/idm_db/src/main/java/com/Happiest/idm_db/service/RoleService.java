package com.Happiest.idm_db.service;

import com.Happiest.idm_db.entities.Role;

import java.util.List;



public interface RoleService 
{
	 public List<Role> findAll();
	 
	 public void save(Role theRole);
}
