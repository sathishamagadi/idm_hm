package com.Happiest.idm_db.service;

import java.util.List;

import javax.transaction.Transactional;

import com.Happiest.idm_db.dto.EnterprisedtohibernateImpl;
import com.Happiest.idm_db.entities.Enterprise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class EnterpriseServiceHibernateImpl implements EnterpriseService {
	
	private EnterprisedtohibernateImpl enterpriseHibernateImpl;
	
	@Autowired
	public EnterpriseServiceHibernateImpl(EnterprisedtohibernateImpl theEnterpriseHibernateImpl) {
		
		 enterpriseHibernateImpl = theEnterpriseHibernateImpl;   
	}

	@Override
	@Transactional
	public List<Enterprise> findAll() {
		return  enterpriseHibernateImpl.findAll();   
	}

	@Override
	@Transactional
	public Enterprise findByEnterpriseCode(String theEnterpriseCode) {
		
		return enterpriseHibernateImpl.findByEnterpriseCode(theEnterpriseCode);
	}

}
