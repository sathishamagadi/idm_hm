package com.Happiest.idm_db.dto;

import java.util.List;

import javax.persistence.EntityManager;

import com.Happiest.idm_db.entities.User;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;




@Repository
public class UserdtohibernateImpl implements Userdto {

    //define field for entityManager
    private EntityManager entityManager;

    @Autowired
    public UserdtohibernateImpl (EntityManager theEntityManager){
        entityManager =  theEntityManager;
    }


    @Override
    public List<User> findAll() {
        //get the current hibernate session
        Session currentSession =  entityManager.unwrap(Session.class);

        //create a query
        Query<User> theQuery = currentSession.createQuery("from User",User.class);

        //execute query and get result list
        List<User> users = theQuery.getResultList();

        //return the results
        return users;
    }

    

}
