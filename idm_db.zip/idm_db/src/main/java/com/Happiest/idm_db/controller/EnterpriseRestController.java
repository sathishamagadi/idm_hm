package com.Happiest.idm_db.controller;

import java.util.List;

import com.Happiest.idm_db.entities.Enterprise;
import com.Happiest.idm_db.service.EnterpriseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping("/api")
public class EnterpriseRestController {
	
private EnterpriseService enterpriseService;
	
	@Autowired
	public EnterpriseRestController(EnterpriseService theEnterpriseService)
	{
		enterpriseService =  theEnterpriseService;
	}
    
	@GetMapping("/enterprises")
	public List<Enterprise> findAllRoles()
	{
		return enterpriseService.findAll();

    }
	
	@GetMapping("/enterprises/{theEnterpriseCode}")
	public Enterprise findByEnterpriseCode(@PathVariable String theEnterpriseCode)
	{
		return enterpriseService.findByEnterpriseCode(theEnterpriseCode);

    }
	
	
	
	
}