package com.Happiest.idm_db.dto;

import com.Happiest.idm_db.entities.Enterprise;

import java.util.List;


public interface Enterprisedto 
{
	
	  public List<Enterprise> findAll();
	  
	  public Enterprise findByEnterpriseCode(String theEnterpriseCode);
}
